/* Mobile-only sign-in gate. Desktop browsing remains unchanged. */
(() => {
  const isPhoneOrTablet = () => window.matchMedia('(max-width: 767px)').matches;
  const path = window.location.pathname.toLowerCase();
  const authPage = path.endsWith('/login.html') || path.endsWith('/signup.html');
  const publicLegalPage = path.endsWith('/terms.html') || path.endsWith('/privacy-policy.html');
  if (!isPhoneOrTablet() || authPage || publicLegalPage) return;

  const reveal = () => document.documentElement.classList.remove('mobile-auth-pending');
  const redirectToLogin = () => window.location.replace(new URL('login.html', window.location.href).href);

  try {
    if (!window.supabase?.createClient || !window.STUDYHUB_SUPABASE_URL || !window.STUDYHUB_SUPABASE_PUBLISHABLE_KEY) {
      reveal();
      return;
    }
    const client = window.studyHubSupabaseClient || (window.studyHubSupabaseClient = window.supabase.createClient(
      window.STUDYHUB_SUPABASE_URL,
      window.STUDYHUB_SUPABASE_PUBLISHABLE_KEY,
      { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }
    ));
    client.auth.getSession().then(({ data, error }) => {
      if (error) throw error;
      if (!data.session?.user) redirectToLogin();
      else reveal();
    }).catch(error => {
      console.error('StudyHub mobile auth check failed:', error);
      reveal();
    });
  } catch (error) {
    console.error('StudyHub mobile auth gate could not start:', error);
    reveal();
  }
})();
